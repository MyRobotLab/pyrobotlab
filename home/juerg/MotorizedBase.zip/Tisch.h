// Tisch.h

#ifndef _TISCH_h
#define _TISCH_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

#define PIN_TISCH_HOEHE A12
#define PIN_PWM1 2
#define PIN_DIR1 26
#define PIN_PWM2 3
#define PIN_DIR2 27
#define PIN_POWER 28

#define TISCH_AUF HIGH
#define TISCH_AB LOW

enum TISCH_STATUS { AUF, AB, STOPP };

void tischSetup();
int getTischHoehe();
TISCH_STATUS getTischStatus();
void tischAuf();
void tischAb();
void tischStopp();

#endif

