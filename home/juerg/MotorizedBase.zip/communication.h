// communication.h

#ifndef _COMMUNICATION_h
#define _COMMUNICATION_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

extern boolean cartControlActive;
extern boolean newData;
extern char receivedChars[32];
extern unsigned long lastMsg;

void recvWithEndMarker();

#endif