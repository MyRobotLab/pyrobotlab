// Distanz.h

#ifndef _DISTANZ_h
#define _DISTANZ_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

#include "MotorizedBase.h"
#include "Fahren.h"

//
// Die Struktur der Parameter des Infrarot-Entfernungsmessers
//
typedef struct ir_sensor {
	int a;
	int b;
	int k;
} ir_sensor;


enum SENSOR_RANGE { NAH, FERN };
#define BODEN_NAH  15
#define BODEN_FERN  22

extern int loopCount;

// funktionen
void setupDistanzMessung();
void calibrate();
void measureDistance();
void logDistancies(int sensorID);
void stopScan();

#define DISTANCE_UNKNOWN 200

int evalMovementRestrictions(MOVEMENT, SENSOR_RANGE, MESSWERT_AUSWERTUNG);

#define MAX_INVOLVED_SENSORS 6

enum DISTANCE_SENSORS {
	VL_NAH, VL_FERN, VR_NAH, VR_FERN,
	LM_NAH, RM_NAH,
	HL_NAH, HL_FERN, HR_NAH, HR_FERN,
	DISTANCE_SENSORS_COUNT
};

// die ScanServos
enum SCAN_SERVOS {
	VL, VR, LM, RM, HL, HR, SCAN_SERVOS_COUNT
};

typedef struct servoDefinition {
	int servoID;
	char servoName[3];
	boolean installed;
	int servoPin;
	int servoDegreeOffset;
} servoDefinition;

typedef struct servoValues {
	int messdirection;
} servoValues;

// Achtung: Adafruit DC Motors benutzen pin 4,7,8 und 12
// Bei Kollision in der Benutzung der Pins st�rzt der Arduino ab
// Mega-PWM-Pins = 2..13, 44,45,46
static servoDefinition servoDefinitions[SCAN_SERVOS_COUNT]{
	{ VL, "VL", true, 11, -10 },
	{ VR, "VR", true, 12, 0 },
	{ LM, "LM", true, 9, 10 },
	{ RM, "RM", true, 5, 10 },
	{ HL, "HL", true, 6, 8 },
	{ HR, "HR", true, 10, 10 }
};

//servoValues servoData[SCAN_SERVOS_COUNT];


enum SENSOR_TYPEN { A41, A21, SENSOR_TYPEN_COUNT };		// Nah, Fern
enum SENSOR_INFO { SENSOR_ID, SENSOR_TYPE, SENSOR_PIN, SWIPE_SERVO_ID, SENSOR_INFO_COUNT };


typedef struct sensorDefinition {
	int sensorID;
	char sensorName[8];
	SENSOR_TYPEN sensorTyp;
	SENSOR_RANGE sensorRange;
	boolean installed;
	int sensorPin;
	int servoID;
	int distanceCorrection;
} sensorDefinition;

static sensorDefinition sensorDefinitions[DISTANCE_SENSORS_COUNT]{
	{ VL_NAH,  "VL_NAH ", A21, NAH, true, A0, VL, -1 },
	{ VL_FERN, "VL_FERN", A21, FERN, true, A2, VL, -3 },
	{ VR_NAH,  "VR_NAH ", A41, NAH, true, A1, VR, 5 },
	{ VR_FERN, "VR_FERN", A21, FERN, true, A3, VR, -3 },
	{ LM_NAH,  "LM_NAH ", A21, NAH, true, A13, LM, -1 },
	{ RM_NAH,  "RM_NAH ", A21, NAH, true, A7, RM, 0 },
	{ HL_NAH,  "HL_NAH ", A21, NAH, true, A8, HL, 0 },
	{ HL_FERN, "HL_FERN", A21, FERN, true, A9, HL, 3 },
	{ HR_NAH,  "HR_NAH ", A21, NAH, true, A10, HR, 0 },
	{ HR_FERN, "HR_FERN", A21, FERN, true, A11, HR, 0 }
};

typedef struct distanceSensorCurrentMeasure {
	int raw[20];
	int AnalogValue;
} distanceSensorCurrentMeasure;

typedef struct distanceSensorValues {
	unsigned long lastMeasurement;
	int Distance;
} distanceSensorValues;


static int directionSensorAssignment[MOVEMENT_COUNT][MAX_INVOLVED_SENSORS]{
	/* STOP              */{ DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT,  DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT },
	/* VORWAERTS         */{ VL_NAH, VL_FERN, VR_NAH, VR_FERN, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT },
	/* VOR_DIAG_RECHTS   */{ VR_NAH, VR_FERN, RM_NAH, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT },
	/* VOR_DIAG_LINKS    */{ VL_NAH, VL_FERN, LM_NAH, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT },
	/* LINKS             */{ VL_NAH, VL_FERN, LM_NAH, HL_NAH, HL_FERN, DISTANCE_SENSORS_COUNT },
	/* RECHTS            */{ VR_NAH, VR_FERN, RM_NAH, HR_NAH, HR_FERN, DISTANCE_SENSORS_COUNT },
	/* RUECKWAERTS       */{ HL_NAH, HL_FERN, HR_NAH, HR_FERN, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT },
	/* RUECK_DIAG_RECHTS */{ HR_NAH, HR_FERN, RM_NAH, DISTANCE_SENSORS_COUNT,DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT },
	/* RUECK_DIAG_LINKS  */{ HL_NAH, HL_FERN, LM_NAH, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT },
	/* DREHEN_LINKS      */{ VL_NAH, VR_NAH, HL_NAH,  HR_NAH, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT },
	/* DREHEN_RECHTS     */{ VL_NAH, VR_NAH, HL_NAH,  HR_NAH, DISTANCE_SENSORS_COUNT, DISTANCE_SENSORS_COUNT }
};



#endif

