// 
// 
// 

#include "communication.h"

void recvWithEndMarker() {
	static byte ndx = 0;
	char endMarker = '\n';
	char rc;

	while (Serial.available() > 0 && newData == false) {
		rc = Serial.read();

		if (rc != endMarker) {
			receivedChars[ndx] = rc;
			ndx++;
			if (ndx >= 32) {
				ndx = 32 - 1;
			}
		}
		else {
			receivedChars[ndx] = '\0'; // terminate the string
			ndx = 0;
			newData = true;
			cartControlActive = true;
			lastMsg = millis();
			//Serial.print("communication.recvWithEndMarker endMarker seen: ");
			//Serial.println(String(receivedChars));
		}
	}
}

