#include <Adafruit_BNO055.h>

extern Adafruit_BNO055 bno;
extern int cartOrientation;

sensors_event_t bnoData;



void readbnoSensorData() {
	bno.getEvent(&bnoData);
	// normalize
	cartOrientation = round(360 - bnoData.orientation.x);

	//Serial.print("bnoData.orientation.x: ");
	//Serial.print(bnoData.orientation.x);
	//Serial.print(", bnoData.orientation.heading: ");
	//Serial.println(bnoData.orientation.heading);

}

void init_bno055() {

	/* Initialise the sensor */
	Serial.println("Check for BNO055");

	while (!bno.begin())
	{
		/* There was a problem detecting the BNO055 ... check your connections */
		Serial.println("Ooops, no BNO055 detected ... Check your wiring or I2C ADDR!");
		delay(1000);
	}
	Serial.println("BNO055 connected");
	delay(500);

	bno.setExtCrystalUse(true);

	/* Get current sensor data (few times at startup)*/
	readbnoSensorData();
	delay(500);
	readbnoSensorData();
	delay(500);
	readbnoSensorData();

}
