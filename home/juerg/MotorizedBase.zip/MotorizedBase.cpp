// 
// 
// 

#include "MotorizedBase.h"
#include "Fahren.h"
#include "Distanz.h"
#include "Tisch.h"
#include "bno055.h"
#include <Adafruit_BNO055.h>
#include "communication.h"


// Configurable Values
int numRepeatedMeasures = 10;
int servoMin = 30;		// servo scan bereich von
int servoRange = 180;		// servo scan bereich bis
int numServoSteps = 30;
int numMeasureSteps = 11;	//
int scanTime = 1000;		// time for distance servo swipe

int minLoopDuration;

// global values
int rotationDirection = -1;		// to swipe from right to left and back from left to right
int currentServoStep = 1;	    // 


MOVEMENT activeCartMovement;
MOVEMENT previousCartMovement;

int ROTATE_SPEED = 180;

int loopCount;
unsigned long workStart;
unsigned long workTime;
int avgWait = 0;

uint8_t cartSpeed;
unsigned long moveStart;
int maxMoveDuration;			// max duration for move

Adafruit_BNO055 bno = Adafruit_BNO055(55);
int cartOrientation = 0;
int prevCartOrientation = 0;
unsigned long lastOrientationChange;
int targetYaw;
int startingYaw = 0;
int currentYaw = 0;

// serial commands
boolean cartControlActive = false;
const byte numChars = 32;
char receivedChars[numChars]; // an array to store the received data
boolean newData = false;

// special states, heartbeat
boolean inCounterClockRotation = false;
boolean inClockwiseRotation = false;
unsigned long lastMsg;
//int lastCurrent = 0;
int testDirection;


void setup()
{
	Serial.begin(115200);

	Serial.println("MotorizedBase v0.9");

	setupFahren();

	setupDistanzMessung();

	tischSetup();

	init_bno055();

	calibrate();

	previousCartMovement = STOP;
	activeCartMovement = STOP;

	Serial.println("!A0");		//cart ready");
}

void stopRotation() {
	inCounterClockRotation = false;
	inClockwiseRotation = false;
}

void checkCommand() {

	String msg;
	int dir;
	int speed;
	int relAngle;
	double ox;
	int servoID;
	int sensorID;
	String sensorDistance;


	if (Serial.available() > 0) {
		recvWithEndMarker();		
		//standalone: SerialMonitor, select Line Feed and send command, 
		// e.g. 11050 for go forward with speed 50
	}

	if (newData) {

		char mode = receivedChars[0];
		// do not log the heartbeat and the orientation query
		if (mode != '5' && mode != '9') {
			Serial.print("new command: ");
			Serial.print("mode: ");
			Serial.print(mode);
			Serial.print("; ");
			Serial.println(receivedChars);
		}

		switch (mode) {
		case '1':  // move
			msg = receivedChars;
			dir = msg.substring(1,2).toInt();
			speed = msg.substring(2, 5).toInt();
			maxMoveDuration = msg.substring(5, 9).toInt();
			moveStart = millis();

			Serial.print("move dir: ");
			Serial.print(dir);
			Serial.print(" speed: ");
			Serial.print(speed);
			Serial.print(" maxMoveDuration: ");
			Serial.print(maxMoveDuration);
			Serial.println();

			cartSpeed = speed;
			setActiveCartMovement(MOVEMENT(dir));

			break;

		// current ox is 0/359 when reset/startup
		case '2':  // rotate counterclockwise, left

			msg = String((char*)receivedChars);
			relAngle = msg.substring(1, 4).toInt();

			cartSpeed = ROTATE_SPEED;
			startingYaw = cartOrientation;
			targetYaw = startingYaw + relAngle;
			lastOrientationChange = millis();
			if (targetYaw > 360) { targetYaw -= 360; }

			Serial.print("msg: "); Serial.print(msg);
			Serial.print(" substring(1,4): "); Serial.println(msg.substring(1, 4));
			Serial.print("rotate counterclock, relAngle: ");
			Serial.print(relAngle);
			Serial.print(" targetYaw: ");
			Serial.print(targetYaw);
			Serial.print(" speed (ROTATE_SPEED): ");
			Serial.println(cartSpeed);

			inCounterClockRotation = true;

			setActiveCartMovement(DREHEN_LINKS);
			break;

		case '3':  // rotate clockwise, right, 3 digits for angle
			msg = receivedChars;
			relAngle = msg.substring(1, 4).toInt();

			startingYaw = cartOrientation;
			targetYaw = startingYaw - relAngle;
			cartSpeed = ROTATE_SPEED;
			lastOrientationChange = millis();

			if (targetYaw < 0) { targetYaw += 360; }

			Serial.print("rotate left, relAngle: ");
			Serial.print(relAngle);
			Serial.print(" targetYaw: ");
			Serial.print(targetYaw);
			Serial.print(" speed (ROTATE_SPEED): ");
			Serial.println(cartSpeed);

			inClockwiseRotation = true;

			setActiveCartMovement(DREHEN_RECHTS);
			break;

		case '4':  // stop
			stopRotation();
			stopCart();
			break;

		case '5':  // getCartOrientation
			// !A9,<orientation>
			readbnoSensorData();
			//Serial.print(String(cartOrientation));
			msg = "!A9," + String(cartOrientation);
			Serial.println(msg);
			break;


		case '7':  // test sensor
			msg = receivedChars;
			MOVEMENT cartDirection;
			// map testDirection to cartDirection
			testDirection = msg.substring(1, 2).toInt();	// forward..backward
			switch (testDirection) {
			case 0:		// forward
				cartDirection = VORWAERTS;
				break;
			case 1:		// left
				cartDirection = LINKS;
				break;
			case 2:		// right
				cartDirection = RECHTS;
				break;
			case 3:		// backward
				cartDirection = RUECKWAERTS;
				break;
			}
			cartSpeed = 0;		// disable movement
			setActiveCartMovement(cartDirection);

			break;

			// TODO! use mode 8 for configuring the basic behaviour of the cart
				// "a" numRepeatedMeasures [10] (check for lower as MAX_REPEATED_MEASURES)
				// "b" servoMin [30]		// 0..90
				// "c" servoRange [120]		// 0..180
				// "d" numServoSteps [30]	// number of servo movements in range
				// "e" numMeasureSteps [11]	// number of measure directions, check for MAX_MEASURE_STEPS)
				// "f" scanTime [1000];		// ms for sweep of servo over servoRange (adjusts loop repetition time)

		case '9':  // heart beat
			cartControlActive = true;
			break;

		default:
			Serial.print("unknown serial command, mode: "); Serial.println(char(mode));
			break;
		}

		newData = false;
	}
}

void loop()
{
	workStart = millis();
	loopCount++;
	//Serial.print("loopCount: ");  Serial.println(loopCount);

	/* Get current rotation sensor data */
	readbnoSensorData();

	if (activeCartMovement != STOP) {
		measureDistance();
	}

	if (activeCartMovement == VORWAERTS || activeCartMovement == RUECKWAERTS) {

		// Check for move-duration-limit
		if ((millis() - moveStart) > maxMoveDuration) {
			Serial.print("maxMoveDuration reached, stopping cart");
			stopCart();
		}

	}
	
	checkCommand();

	

	//Serial.print("in loop, cartControlActive: ");Serial.println(cartControlActive);
//	if (!cartControlActive) {
//		followJoystick();
//	}
//	else {

	// check for heartbeat from controlling computer
	if (cartControlActive && millis() - lastMsg > 5000) {  // 500
		Serial.println("timeout command messages, stop");
		cartControlActive = false;
		inCounterClockRotation = false;
		inClockwiseRotation = false;
		stopCart();
	}
	//Serial.print("main loop active move "); Serial.println(getMovementName(activeCartMovement));
	if (activeCartMovement != STOP) {
		moveCart(activeCartMovement);
	}
//	}


	// if in rotation check for target orientation reached
	if (inCounterClockRotation || inClockwiseRotation) {

		/* Get current orientation data */
		readbnoSensorData();
		if (cartOrientation != prevCartOrientation) {
			prevCartOrientation = cartOrientation;
			lastOrientationChange = millis();
			//Serial.print("currentYaw: ");
			//Serial.print(currentYaw);
			//Serial.print(" targetYaw: ");
			//Serial.println(targetYaw);
		}
		else {
			// same orientation, check for progress
			if (millis() - lastOrientationChange > 3000) {
				Serial.print("no progress in rotation, stop ");
				stopCart();
				stopRotation();
			}
		}
		currentYaw = cartOrientation;
	}

	if (inClockwiseRotation) {

		// when rotating Clockwise (cartOrientation decreasing) 
		if ((startingYaw < targetYaw) && (currentYaw <= startingYaw)) {
			currentYaw = cartOrientation + 360;
		}
		if (currentYaw - 1 <= targetYaw) {
			Serial.println("stop clockwise rotation");
			Serial.print("startingYaw: ");
			Serial.print(startingYaw);
			Serial.print(" currentYaw: ");
			Serial.print(currentYaw);
			Serial.print(" targetYaw: ");
			Serial.println(targetYaw);

			stopCart();
			stopRotation();
		}
	}

	if (inCounterClockRotation) {

		// current Yaw increasing, compensate for step over full circle
		if ((startingYaw > targetYaw) && (currentYaw >= startingYaw)) {
			currentYaw = cartOrientation - 360;
		}
		if (currentYaw + 1 >= targetYaw) {
			Serial.println("stop counterclock rotation");
			Serial.print("startingYaw: ");
			Serial.print(startingYaw);
			Serial.print(" currentYaw: ");
			Serial.print(currentYaw);
			Serial.print(" targetYaw: ");
			Serial.println(targetYaw);
			stopCart();
			stopRotation();
		}
	}

	// this compensates runtime differences in loop cycles due to actions required
	// if all time is used up start next loop
	// if partial time is used wait until the next planned cycle start
	workTime = millis() - workStart;
	minLoopDuration = scanTime / numServoSteps; //25;
	if (workTime < minLoopDuration) {
		avgWait += minLoopDuration - workTime;
		if (loopCount % 20 == 0) {
			//Serial.print("avg wait time "); Serial.println(avgWait / 20);
			avgWait = 0;
		}
		delay(minLoopDuration - workTime);
		
	}
}
