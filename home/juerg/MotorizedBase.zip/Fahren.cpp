// 
// 
// 
#include <Wire.h>
#include "MotorizedBase.h"
#include "Fahren.h"
#include "Distanz.h"
#include "Tisch.h"

#include <Adafruit_MotorShield.h>
#include "utility/Adafruit_MS_PWMServoDriver.h"
// A C H T U N G - benutzen f�r DC-Motoren Pins 4, 7, 8 und 12  ==> unklar, da comm �ber I2C sollten diese Pins eigentlich frei sein???

extern int minLoopDuration;
extern uint8_t cartSpeed;
extern MOVEMENT activeCartMovement;
extern MOVEMENT previousCartMovement;
extern boolean servoInvolved[SCAN_SERVOS_COUNT];
extern boolean sensorInvolved[DISTANCE_SENSORS_COUNT];

Adafruit_MotorShield AFMS = Adafruit_MotorShield();

Adafruit_DCMotor *fl = AFMS.getMotor(1);
Adafruit_DCMotor *fr = AFMS.getMotor(2);
Adafruit_DCMotor *br = AFMS.getMotor(3);
Adafruit_DCMotor *bl = AFMS.getMotor(4);

const int joyX = A14;  // Arduino Pin Joystick x
const int joyY = A15;  // Arduino Pin Joystick y
const int joyZ = 52;   // Arduino Pin Joystick pushdown

uint8_t prevCartSpeed = 50;
uint8_t maxSpeedIncrease = 3; //minLoopDuration / 5;

int XPos;
int YPos;
int ZPos;
float fahrdirection;
float oldFahrdirection = 999;

boolean forceSlow = false;
DISTANCE_STATUS distanzStatus;


int moves[11][4]{
	/* STOP              */{ RELEASE,  RELEASE,  RELEASE,  RELEASE },
	/* VORWAERTS         */{ FORWARD,  FORWARD,  FORWARD,  FORWARD },
	/* VOR_DIAG_RECHTS   */{ RELEASE,  FORWARD,  FORWARD,  RELEASE },
	/* VOR_DIAG_LINKS    */{ FORWARD,  RELEASE,  RELEASE,  FORWARD },
	/* LINKS             */{ FORWARD,  BACKWARD, BACKWARD, FORWARD },
	/* RECHTS            */{ BACKWARD, FORWARD,  FORWARD,  BACKWARD },
	/* RUECKWAERTS       */{ BACKWARD, BACKWARD, BACKWARD, BACKWARD },
	/* RUECK_DIAG_RECHTS */{ BACKWARD, RELEASE,  RELEASE,  BACKWARD },
	/* RUECK_DIAG_LINKS  */{ RELEASE,  BACKWARD, BACKWARD, RELEASE },
	/* DREHEN_LINKS      */{ FORWARD,  BACKWARD, FORWARD,  BACKWARD },
	/* DREHEN_RECHTS     */{ BACKWARD, FORWARD,  BACKWARD, FORWARD }
};


void setupFahren() {

	// Druck-Schalter JoyStick als Input
	pinMode(joyZ, INPUT_PULLUP);
	//digitalWrite(joyZ, HIGH);
	Serial.println("vor AFMS.begin");
	AFMS.begin();
	Serial.println("SetupFahren done");
}


String getMovementName(MOVEMENT m) {
	String moveName[11] = { "stop","vor","vor_diag_rechts","vor_diag_links","links","rechts","rueckwaerts","rueck_diag_rechts","rueck_diag_links","drehen_links","drehen_rechts" };
	return moveName[m];
}

void setActiveCartMovement(MOVEMENT newCartDirection) {
	if (newCartDirection != activeCartMovement) {
		Serial.print("new direction: "); Serial.println(getMovementName(newCartDirection));

		int sensorID;
		int servoID;
		
		// reset and update the servo and sensor list for the new cartDirection
		for (int m = 0; m < SCAN_SERVOS_COUNT; m++) { servoInvolved[m] = false; }
		for (int s = 0; s < DISTANCE_SENSORS_COUNT; s++) { sensorInvolved[s] = false; }

		for (int s = 0; s < MAX_INVOLVED_SENSORS; s++) {
			sensorID = directionSensorAssignment[newCartDirection][s];
			if (sensorID != DISTANCE_SENSORS_COUNT) {
				servoID = sensorDefinitions[sensorID].servoID;
				sensorInvolved[sensorID] = true;
				servoInvolved[servoID] = true;
			}
		}

		// testoutput sensor involved
		//for (int m = 0; m < DISTANCE_SENSORS_COUNT; m++) { 
		//		Serial.print(" sensor involved "); Serial.print(m); Serial.print(": "); Serial.println(sensorInvolved[m]);
		//}
		previousCartMovement = activeCartMovement;
		activeCartMovement = newCartDirection;
	}
}

void stopMotors() {

	prevCartSpeed = 50;
	fr->run(RELEASE);
	fl->run(RELEASE);
	br->run(RELEASE);
	bl->run(RELEASE);

	tischStopp();
}

void setCartSpeed(uint8_t speed) {

	//Serial.println("setCartSpeed");
	// limit amount of acceleration
	if (speed > prevCartSpeed + maxSpeedIncrease) {
		//Serial.print("gewuenschter speed: "); Serial.print(speed);
		speed = prevCartSpeed + maxSpeedIncrease;
		//Serial.print(", gesetzter speed: "); Serial.println(speed);
	}
	
	prevCartSpeed = speed;
	//Serial.print("acceleration ramp speed, prevCartSpeed "); Serial.print(speed); Serial.print(", "); Serial.println(prevCartSpeed);

	fl->setSpeed(speed);
	fr->setSpeed(speed);
	br->setSpeed(speed);
	bl->setSpeed(speed);

}

void moveCart(MOVEMENT direction) {

	setActiveCartMovement(direction);

	int FreiheitNahMin = evalMovementRestrictions(direction, NAH, MINIMUM);
	int FreiheitNahMax = evalMovementRestrictions(direction, NAH, MAXIMUM);
	int FreiheitFernMin = evalMovementRestrictions(direction, FERN, MINIMUM);
	int FreiheitFernMax = evalMovementRestrictions(direction, FERN, MAXIMUM);

	if (FreiheitNahMin == -1 || FreiheitFernMin == -1) {
		if (distanzStatus != OUT_OF_DATE) {
			Serial.println("no current values for all involved distance sensors");
			distanzStatus = OUT_OF_DATE;
		}

	} else {

		//// die Distanzen der Sensoren der Fahr-direction
		//for (int i = 0; i <= 3; i++) {
		//	int sensorID = directionSensorAssignment[direction][i];
		//	logDistancies(sensorID);
		//}

		// mit cartSpeed == 0 kann eine Distanzmessung durchgef�hrt werden ohne Bewegung
		if (cartSpeed == 0) {
			return;
		}

		if (FreiheitNahMin > BODEN_NAH_MIN && FreiheitNahMax < BODEN_NAH_MAX) {

			setCartSpeed(cartSpeed);
			fr->run(moves[direction][FRONT_RIGHT]);
			fl->run(moves[direction][FRONT_LEFT]);
			br->run(moves[direction][BACK_RIGHT]);
			bl->run(moves[direction][BACK_LEFT]);
		}

		// teste auf OBSTACLE
		if (FreiheitNahMin <= BODEN_NAH_MIN) {
			if (distanzStatus != OBSTACLE) {
				Serial.print("!A2,");Serial.println(FreiheitNahMin);
			}
			distanzStatus = OBSTACLE;
			stopMotors();
		}
		else {  // wenn kein OBSTACLE teste auf ABYSS

			if (FreiheitNahMax >= BODEN_NAH_MAX) {
				if (distanzStatus != ABYSS) {
					Serial.print("!A3,");Serial.println(FreiheitNahMax);
				}
				distanzStatus = ABYSS;
				stopMotors();
			}
		}

		//Serial.print("Freiheit fern: "); Serial.println(FreiheitFern);
		// speed reduction in case of close obstacle or abyss
		if (FreiheitFernMin < BODEN_FERN_MIN && FreiheitFernMax > BODEN_FERN_MAX) {
			if (!forceSlow) {
				Serial.print("halbe kraft, Freiheit fern min: "); Serial.print(FreiheitFernMin); Serial.print(" max: "); Serial.println(FreiheitFernMax);
			}
			forceSlow = true;
		}
		else {
			if (forceSlow) {
				Serial.print("volle kraft, Freiheit fern min: "); Serial.print(FreiheitFernMin); Serial.print(" max: "); Serial.println(FreiheitFernMax);
			}
			forceSlow = false;
		}
	}
}


void followJoystick() {

	// den joystick lesen
	int rawX = analogRead(joyX);
	int rawY = analogRead(joyY);
	XPos = int((rawX - 517) / 10);
	YPos = int((rawY - 513) / 10);
	ZPos = digitalRead(joyZ);

	//Serial.print("Joystick X,Y,Z: "); 
	//Serial.print("rawX: "); Serial.print(rawX); Serial.print(", rawY: "); Serial.print(rawY); 
	//Serial.print(", XPos: ");	Serial.print(XPos); Serial.print(", yPos:"); Serial.print(YPos); 
	//Serial.print(", Button "); 	Serial.println(ZPos);

	// Ruhezone Zenter
	if (abs(XPos) < 10) XPos = 0;
	if (abs(YPos) < 10) YPos = 0;

	fahrdirection = degrees(atan2(XPos, YPos));

	//if (fahrdirection != oldFahrdirection) Serial.print("Joystick direction degrees "); {
	//	oldFahrdirection = fahrdirection;
	// Serial.print("in follow Joystick, fahrdirection: "); Serial.println(fahrdirection);
	//}

	// benutze den gr�sseren Ausschlag des Joystick als Geschwindigkeit-Vorgabe
	if (abs(XPos) > abs(YPos)) {
		cartSpeed = map(abs(XPos), 0, 51, 0, 150);  // reduziere Geschwindigkeit von Seitw�rts-Bewegungen (150 max)
	}
	else {
		cartSpeed = map(abs(YPos), 0, 51, 0, 240);
	}

	// fern-sensoren k�nnen forceSlow verlangen
	if (forceSlow) cartSpeed = min(100, cartSpeed);

	
	if (cartSpeed == 0 && activeCartMovement != STOP) {
		Serial.println("Joystick in Stop-Position");
		stopMotors();
		stopScan();
		setActiveCartMovement(STOP);
	}

	if (cartSpeed == 0 && getTischStatus() != STOPP) {
		tischStopp();
	}

	if (cartSpeed > 0) {

		if (ZPos == 1) {  // Drehung nicht aktiv

			if (fahrdirection > -22.5   && fahrdirection <= -22.5 + 45)   moveCart(RUECKWAERTS);
			if (fahrdirection > 22.5    && fahrdirection <= 22.5 + 45)    moveCart(RUECK_DIAG_LINKS);
			if (fahrdirection > 67.5    && fahrdirection <= 67.5 + 45)    moveCart(LINKS);
			if (fahrdirection > 112.5   && fahrdirection <= 112.5 + 45)   moveCart(VOR_DIAG_LINKS);
			if (fahrdirection > 157.5   || fahrdirection <= -157.5)       moveCart(VORWAERTS);
			if (fahrdirection > -157.5  && fahrdirection <= -157.5 + 45)  moveCart(VOR_DIAG_RECHTS);
			if (fahrdirection > -112.5  && fahrdirection <= -112.5 + 45)  moveCart(RECHTS);
			if (fahrdirection > -67.5   && fahrdirection <= -67.5 + 45)   moveCart(RUECK_DIAG_RECHTS);
		}
		else { // gedr�ckte Drehtaste
			if (fahrdirection > 67.5    && fahrdirection <= 67.5 + 45)    moveCart(DREHEN_LINKS);
			if (fahrdirection > -112.5  && fahrdirection <= -112.5 + 45)  moveCart(DREHEN_RECHTS);

			if (fahrdirection > -22.5   && fahrdirection <= -22.5 + 45)   tischAuf();
			if (fahrdirection > 157.5   || fahrdirection <= -157.5)       tischAb();

		}
	}
}

void stopCart() {
	stopMotors();
	stopScan();
	setActiveCartMovement(STOP);
	Serial.println("!A5");
}

