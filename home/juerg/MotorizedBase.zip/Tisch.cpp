// 
// 
// 

#include "Tisch.h"

TISCH_STATUS tischStatus = STOPP;

int speed1Up = 245;
int speed2Up = 205;
int speed1Down = 232;
int speed2Down = 190;


void tischSetup()
{
	pinMode(PIN_PWM1, OUTPUT);
	analogWrite(PIN_PWM1, 0);
	pinMode(PIN_DIR1, OUTPUT);

	pinMode(PIN_PWM2, OUTPUT);
	analogWrite(PIN_PWM2, 0);
	pinMode(PIN_DIR2, OUTPUT);

	pinMode(PIN_POWER, OUTPUT);
	digitalWrite(PIN_POWER, LOW);

	Serial.println("Tisch setup done");
}

TISCH_STATUS getTischStatus() {
	return tischStatus;
}

int getTischHoehe() {

	int Wert = analogRead(PIN_TISCH_HOEHE);

	return Wert;
}


void tischAuf() {

	if (tischStatus != AUF) {

		tischStatus = AUF;

		Serial.println("Tisch auf");

		digitalWrite(PIN_POWER, HIGH);
		digitalWrite(PIN_DIR1, TISCH_AUF);
		digitalWrite(PIN_DIR2, TISCH_AUF);

		analogWrite(PIN_PWM1, speed1Up);
		analogWrite(PIN_PWM2, speed2Up);

	}
}

void tischAb() {

	if (tischStatus != AB) {

		if (getTischHoehe() < 800) {

			tischStatus = AB;

			Serial.println("Tisch ab");

			digitalWrite(PIN_POWER, HIGH);
			digitalWrite(PIN_DIR1, TISCH_AB);
			digitalWrite(PIN_DIR2, TISCH_AB);

			analogWrite(PIN_PWM1, speed1Down);
			analogWrite(PIN_PWM2, speed2Down);
		}
		else {
			Serial.print("Tisch Ab blockiert "); Serial.println(getTischHoehe());
		}
	}
	if (getTischHoehe() > 800) {
		tischStopp();
	}
}

void tischStopp() {

	if (tischStatus != STOPP) {

		tischStatus = STOPP;
		Serial.print("Tisch stopp: "); Serial.println(getTischHoehe());

		digitalWrite(PIN_POWER, LOW);
		analogWrite(PIN_PWM1, 0);
		analogWrite(PIN_PWM2, 0);
	}
}


