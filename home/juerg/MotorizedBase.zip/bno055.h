// bno055.h

#ifndef _bno055_h
#define _bno055_h

#if defined(ARDUINO) && ARDUINO >= 100
#include "arduino.h"
#else
#include "WProgram.h"
#endif

void init_bno055();

int normalized(int theta);

void readbnoSensorData();

#endif