// 
// 
// 
#include "Distanz.h"
#include "MotorizedBase.h"
#include "Fahren.h"
#include "Tisch.h"

#include <Servo.h>

extern int minLoopDuration;
extern MOVEMENT activeCartMovement;

#define min(a,b) ((a)<(b)?(a):(b))

extern int rotationDirection;		// to swipe from right to left and back from left to right
extern int currentServoStep;	    // 

Servo Servos[SCAN_SERVOS_COUNT];
//
// Die Parametereigenschaften der Sensoren
// 
ir_sensor GP2Y0A21YK = { 5461, -17, 2 };
ir_sensor GP2Y0A41YK = { 1500, -11, 0 };

distanceSensorValues sensorData[DISTANCE_SENSORS_COUNT][MAX_MEASURE_STEPS];
distanceSensorCurrentMeasure sensorDataCurrentMeasure[DISTANCE_SENSORS_COUNT];

// the list of used servos and sensors in current cartDirection
boolean servoInvolved[SCAN_SERVOS_COUNT];
boolean sensorInvolved[DISTANCE_SENSORS_COUNT];
int currentMeasureIndex;


void setupDistanzMessung() {
	int Pin;
	for (int i = 0; i < SCAN_SERVOS_COUNT; i++) {
		Pin = servoDefinitions[i].servoPin;
		if (servoDefinitions[i].installed) pinMode(Pin, OUTPUT);
	}

	for (int i = 0; i < DISTANCE_SENSORS_COUNT; i++) {
		Pin = sensorDefinitions[i].sensorPin;

		// pullup aktivieren
		pinMode(Pin, OUTPUT);
		digitalWrite(Pin, INPUT_PULLUP);
		pinMode(Pin, INPUT);
	}
}


// distanz 021 20..80 cm
// Konvertieren der Werte des Infrarot-Entfernungsmessers in Centimeter 
// Gibt 200 aus, wenn kein sinnvoller Messwert vorhanden ist
//
int analogToDistanz(ir_sensor sensor, int adc_value)
{
	if (adc_value < 50 || adc_value > 800)
	{
		return 200;	//keine Messung m�glich
	}
	return sensor.a / (adc_value + sensor.b) - sensor.k;
}



/////////////////////////
/////////////////////////
int nextServoStep() {

	if (currentServoStep > 19 || currentServoStep < 1) {
		rotationDirection = -rotationDirection;
	}
	currentServoStep += rotationDirection;

	int newDirection;

	// for all involved servos of the requested cartDirection rotate to next step
	for (int servoID = 0; servoID < SCAN_SERVOS_COUNT; servoID++) {
		if (servoInvolved[servoID]) {

			// rotate servo for measurement
			attachServo(servoID);		// conditional attach
			newDirection = (currentServoStep * (servoRange / numServoSteps)) + 
				servoMin +
				servoDefinitions[servoID].servoDegreeOffset;
			//Serial.print("servoID "); Serial.print(servoID);Serial.print(" dir "); Serial.println(newDirection);
			Servos[servoID].write(newDirection);
		}
	}
	delay(20);

	//Serial.print("currentServoStep "); Serial.println(currentServoStep);
	return;
}



/////////////////////////////////////////////
// check for current data in distance sensor values
/////////////////////////////////////////////
boolean isDataCurrent(int sensorID) {

	unsigned long oldestMeasurement = pow(2, 32) - 1;
	for (int i = 0; i < numMeasureSteps; i++) {
		oldestMeasurement = min(oldestMeasurement, sensorData[sensorID][i].lastMeasurement);
	}
	return millis() - oldestMeasurement < 2*scanTime;
}

// finde kleinste Distanz im Buffer
int minDistance(int sensorID) {

//Serial.println("kleinsteDistanz ");

int smallestValue = 100;
for (int i = 0; i < numMeasureSteps; i++) {
	if (sensorData[sensorID][i].Distance > 0 && sensorData[sensorID][i].Distance != DISTANCE_UNKNOWN) {
		smallestValue = min(smallestValue, sensorData[sensorID][i].Distance);
	}

	//Serial.print("Sensor "); Serial.print(sensorDefinitionen[sensorID].sensorName);
	//Serial.print(" direction "); Serial.print(i);
	//Serial.print(" Distanz "); Serial.println(sensorDaten[sensorID][i].Distanz);


}
//Serial.print(" kleinsteDistanz.kleinsterWert "); Serial.println(kleinsterWert);
return smallestValue;
}


// finde gr�sste Distanz im Buffer
int maxDistance(int sensorID) {

	//Serial.println("kleinsteDistanz ");

	int largestValue = 0;
	for (int i = 0; i < numMeasureSteps; i++) {
		if (sensorData[sensorID][i].Distance > 0 && sensorData[sensorID][i].Distance != DISTANCE_UNKNOWN) {
			largestValue = max(largestValue, sensorData[sensorID][i].Distance);
		}
	}
	//Serial.print(" kleinsteDistanz.kleinsterWert "); Serial.println(kleinsterWert);
	return largestValue;
}

// sort an array, modifies the passed in array
void bubbleSort(int arr[], int numItems) {
	boolean swapped = true;
	int j = 0;
	int tmp;

	// repeat until no swappes occur anymore
	while (swapped) {
		swapped = false;
		j++;
		for (int i = 0; i < numItems - j; i++) {
			if (arr[i] > arr[i + 1]) {
				tmp = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = tmp;
				swapped = true;
			}
		}
	}
	//Serial.print("sorted: ");
	//for (int i = 0; i < numItems; i++) {
	//	Serial.print(arr[i]); Serial.print(", ");
	//}
	//Serial.println();
}

void calcDistanceAverage() {

	for (int sensorID = 0; sensorID < DISTANCE_SENSORS_COUNT; sensorID++) {
		if (sensorInvolved[sensorID]) {
			//Serial.print("sensorID: "); Serial.print(sensorID);

			// sort the raw values
			bubbleSort(sensorDataCurrentMeasure[sensorID].raw, numRepeatedMeasures);

			int avg = 0;

			// leave out top and bottom 2 values for average calculation
			for (int m = 2; m < numRepeatedMeasures-2; m++) {
				avg += sensorDataCurrentMeasure[sensorID].raw[m];
			}

			if (sensorDefinitions[sensorID].sensorTyp == A41) {
				sensorData[sensorID][currentMeasureIndex].Distance = 
					analogToDistanz(GP2Y0A41YK, avg / (numRepeatedMeasures - 4))
					+ sensorDefinitions[sensorID].distanceCorrection;
			}

			if (sensorDefinitions[sensorID].sensorTyp == A21) {
				sensorData[sensorID][currentMeasureIndex].Distance = 
					analogToDistanz(GP2Y0A21YK, avg / (numRepeatedMeasures - 4))
					+ sensorDefinitions[sensorID].distanceCorrection;
			}
			// update last measure time for this sensor and servo direction
			sensorData[sensorID][currentMeasureIndex].lastMeasurement = millis();		// Zeitpunkt der Messung
			
		}
	}
}

void attachServo(int servoID) {
	if (!Servos[servoID].attached()) {
		int pin = servoDefinitions[servoID].servoPin;
		Servos[servoID].attach(servoDefinitions[servoID].servoPin);
	}
}

/////////////////////////
// get sensor distance values for current servo direction
// and for all sensors in the movement direction
/////////////////////////
void measureDistance() {

	// not every servo step is a measure step
	if (currentServoStep % 2 != 0) {
		nextServoStep();
		return;
	}

	currentMeasureIndex = currentServoStep / 2;
	//Serial.print(" currentMeasureIndex "); Serial.println(currentMeasureIndex);

	// reset the analog values total for the sensors
	for (int sensorID = 0; sensorID < DISTANCE_SENSORS_COUNT; sensorID++) {
		sensorDataCurrentMeasure[sensorID].AnalogValue = 0;
	}

	// do a number of repeated measures and store the average distance
	for (int m = 0; m < numRepeatedMeasures; m++) {

		// the sensors involved in the cartDirection
		for (int sensorID = 0; sensorID < DISTANCE_SENSORS_COUNT; sensorID++) {

			if (sensorInvolved[sensorID]) {

				sensorDataCurrentMeasure[sensorID].raw[m] = analogRead(sensorDefinitions[sensorID].sensorPin);
			}
		}
		//delay(1);

	}
	calcDistanceAverage();


	// log the distancies of the sensors of the movement cartDirection
	// once for every sweep
	if (currentServoStep == 20 && activeCartMovement != STOP) {
		for (int sensorID = 0; sensorID < DISTANCE_SENSORS_COUNT; sensorID++) {
			//int sensorID = directionSensorAssignment[activeCartMovement][i];
			if (sensorInvolved[sensorID]) {
				logDistancies(sensorID);
			}
		}
	}

	nextServoStep();

}


/////////////////////////
/////////////////////////
void logDistancies(int sensorID) {

	// !A1,<sensorID>,<numMeasureDirections>,[numMeasureDirections<value>,]
	Serial.print("!A1,"); 
	Serial.print(sensorID); Serial.print(",");
	Serial.print(numMeasureSteps); Serial.print(",");

	for (int k = 0; k < numMeasureSteps; k++) {
		Serial.print(sensorData[sensorID][k].Distance); Serial.print(",");
	}
	Serial.println();
}


// gibt die ungef�hre Distanz in cm zum n�chsten OBSTACLE / ABYSS in Fahrtdirection
int evalMovementRestrictions(MOVEMENT direction, SENSOR_RANGE range, MESSWERT_AUSWERTUNG minmax) {

	// get requested limit distance of involved sensors
	int closestObstacle = 100;
	int farthestObstacle = 0;

	// for all involved distance sensors
	for (int sensorID = 0; sensorID < DISTANCE_SENSORS_COUNT; sensorID++) {
		if (sensorInvolved[sensorID]) {
			sensorDefinition *senDef = &sensorDefinitions[sensorID];

			if (senDef->installed && senDef->sensorRange == range) {

				//Serial.print("evalMovementRestrictions "); Serial.println(sensorID);
				if (!isDataCurrent(sensorID)) { 
					return -1; 
				} else {

					// minimal distance of involved sensors
					closestObstacle = min(closestObstacle, minDistance(sensorID));

					// maximale Distanz aller installierten Sensoren der direction
					farthestObstacle = max(farthestObstacle, maxDistance(sensorID));

				}
			}
		}
	}

	if (minmax == MINIMUM) {
		return closestObstacle;
	} else { 
		return farthestObstacle; 
	}

}

void resetServo(int servoID) {

	// move servo to start position (min)
	int offset = servoDefinitions[servoID].servoDegreeOffset;
	Servos[servoID].write(servoMin + offset);

	// will cause first move to servo reset position where it is after a stop
	currentServoStep = 1;
	rotationDirection = -1;
}

void stopScan() {

	for (int servoID = 0; servoID < SCAN_SERVOS_COUNT; servoID++) {

		resetServo(servoID);
	}

	// allow servos to move to the reset position before detaching them
	delay(100);

	for (int servoID = 0; servoID < SCAN_SERVOS_COUNT; servoID++) {
		Servos[servoID].detach();
	}
	//Serial.println("distance scan stopped");
}


void calibrate() {

	Serial.println("start distance sensor comparison");
	int pin;
	int offset;
	
	// Vergleich der Sensoren, cart freistehend positionieren
	for (int servoID = 0; servoID < SCAN_SERVOS_COUNT; servoID++) {

		pin = servoDefinitions[servoID].servoPin;
		Serial.print("servo pin: "); Serial.println(pin);
		pinMode(pin, OUTPUT);
		Servos[servoID].attach(pin);
		offset = servoDefinitions[servoID].servoDegreeOffset;
		Servos[servoID].write(90 + offset);
	}
	Serial.println("Servos to middle Position");
	delay(100);

	int raw;
	int distanz;
	String name;
	int korrektur;


	for (int sensorID = 0; sensorID < DISTANCE_SENSORS_COUNT; sensorID ++) {
	//for (int sensorID = 0; sensorID < 4; sensorID++) {
			pin = sensorDefinitions[sensorID].sensorPin;
			name = sensorDefinitions[sensorID].sensorName;
			korrektur = sensorDefinitions[sensorID].distanceCorrection;

			raw = 0;
			for (int j = 0; j < numRepeatedMeasures; j++) {
				raw += analogRead(pin);
			}

			raw = raw / numRepeatedMeasures;
			//Serial.print("pin: "); Serial.print(pin);
			//Serial.print(" raw: "); Serial.print(raw);

			char s[12];

			if (sensorDefinitions[sensorID].sensorTyp == A41) {
				distanz = analogToDistanz(GP2Y0A41YK, raw);
				Serial.print("A41 ");
			}

			if (sensorDefinitions[sensorID].sensorTyp == A21) {
				distanz = analogToDistanz(GP2Y0A21YK, raw);
				Serial.print("A21 ");
			}
			if (sensorDefinitions[sensorID].installed) {
				sprintf(s, "%3d", raw);
				Serial.print(name); Serial.print(" raw "); Serial.print(raw); 
				sprintf(s, ", %3d", distanz);
				Serial.print(s); Serial.print(" cm");
				sprintf(s, ", %3d", korrektur);
				Serial.print(" Korrektur: "); Serial.print(s); 
				sprintf(s, "%3d", distanz + korrektur);
				Serial.print(" Distanz ");  Serial.print(s);
			}
			Serial.println();
		}
		Serial.println();


	Serial.println("comparison done");

	for (int servoID = 0; servoID < SCAN_SERVOS_COUNT; servoID++) {

		//pin = servoDefinitions[servoID].servoPin;
		offset = servoDefinitions[servoID].servoDegreeOffset;
		Servos[servoID].write(servoMin + offset);
	}
	delay(100);
	for (int servoID = 0; servoID < SCAN_SERVOS_COUNT; servoID++) {
		Servos[servoID].detach();
	}
	Serial.print("Position Tisch: "); Serial.println(getTischHoehe());
}