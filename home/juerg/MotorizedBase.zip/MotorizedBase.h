// MotorizedBase.h

#ifndef _MOTORIZEDBASE_h
#define _MOTORIZEDBASE_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif



enum MOVEMENT {
	STOP, VORWAERTS, VOR_DIAG_RECHTS, VOR_DIAG_LINKS,
	LINKS, RECHTS,
	RUECKWAERTS, RUECK_DIAG_RECHTS, RUECK_DIAG_LINKS,
	DREHEN_LINKS, DREHEN_RECHTS,
	MOVEMENT_COUNT
};

#define MAX_MEASURE_STEPS 15
#define MAX_REPEATED_MEASURES 15

// Configurable Values
extern int numRepeatedMeasures;
extern int servoMin;		// servo scan bereich von
extern int servoRange;		// servo scan bereich bis
extern int numServoSteps;
extern int numMeasureSteps;	//
extern int scanTime;		// time for distance servo swipe

#endif

