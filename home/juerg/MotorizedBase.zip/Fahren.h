// Fahren.h

#ifndef _FAHREN_h
#define _FAHREN_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

extern char receivedChars[32];
extern int targetYaw;
extern boolean inRotation;

#define BODEN_NAH_MIN  9
#define BODEN_NAH_MAX  20
#define BODEN_FERN_MIN  17
#define BODEN_FERN_MAX  28

enum MOTORS { FRONT_RIGHT, FRONT_LEFT, BACK_RIGHT, BACK_LEFT };
enum MESSWERT_AUSWERTUNG {MINIMUM, MAXIMUM};
enum DISTANCE_STATUS { OBSTACLE, ABYSS, FREE, OUT_OF_DATE };


// Initialisierung der Bewegungsteile
void setupFahren();

// folge dem Joystick
void followJoystick();

// Fahrtdirection
void setActiveCartMovement(MOVEMENT);
String getMovementName(MOVEMENT);

// stoppe base
void stopCart();

// setze die Fahrtgeschwindigkeit
void setCartSpeed(uint8_t speed);

// fahren
void moveCart(MOVEMENT direction);

void attachServo(int servoID);

#endif

